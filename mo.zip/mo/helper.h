#pragma once

// helper.h
#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <algorithm>

template<typename T> void show(T& c)
{
	for (auto& n : c)
		std::cout << n << ", ";

	std::cout << std::endl;
}
// �ݺ��� 2���� ������ ����ϴ� �Լ�
template<typename Iter> void show(Iter first, Iter last)
{
	while (first != last)
	{
		std::cout << *first << ", ";
		++first;
	}
	std::cout << std::endl;
}
