#include <iostream>
using namespace std;

class Mutex
{
public:
	void Lock()   { cout << "Mutex Lock" << endl; }
	void Unlock() { cout << "Mutex Unlock" << endl; }
};


class Cursor
{
private:
	Cursor() {}
	Cursor(const Cursor&);
	void operator=(const Cursor&);

	static Cursor* sInstance;
	static Mutex   sLock;
public:

	static Cursor& getInstance()
	{
		sLock.Lock();

		if ( sInstance == 0 )
			sInstance = new Cursor;

		sLock.Unlock();

		return *sInstance;
	}
};
Cursor* Cursor::sInstance = 0;
Mutex   Cursor::sLock;

int main()
{
	Cursor& c1 = Cursor::getInstance();
}


