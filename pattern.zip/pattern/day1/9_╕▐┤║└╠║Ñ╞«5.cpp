// 6_�޴�
/*
#include <iostream>
#include <string>
#include <vector>
#include <conio.h>
#include <functional>
using namespace std::placeholders;
using namespace std;


#define clrscr()   system("cls")

class BaseMenu
{
	string title;
public:
	BaseMenu( string s) : title(s) {}

	virtual ~BaseMenu() {} // ��� �θ��� �Ҹ��ڴ� �����̾�� �Ѵ�!

	string getTitle() { return title; }

	virtual void command() = 0;
};
//-----------------------------------------------------------

class MenuItem : public BaseMenu
{
	int id;

	typedef function<void()> HANDLER;

	vector<HANDLER> v;
public:
	MenuItem( string s, int n ) : BaseMenu(s), id(n) {}

	void addHandler( HANDLER h ) { v.push_back(h); }

	void command() 
	{
		for ( int i = 0; i < v.size(); i++)
			v[i]();
	}
};




//-----------------------------------
class PopupMenu : public BaseMenu
{
	vector< BaseMenu* > v; // �ٽ�!
public:
	PopupMenu(string s) : BaseMenu(s) {}


	~PopupMenu()
	{
		for ( int i = 0; i < v.size(); i++ )
			delete v[i];
	}




	void addMenu( BaseMenu* p ) { v.push_back(p);  }

	void command()
	{
		while( 1 )
		{
			clrscr(); // ȭ�������
			int sz = v.size();
			for ( int i = 0; i < sz ; i++)
			{
				cout << i + 1 << ". " << v[i]->getTitle() << endl;
			}
			cout << sz + 1 << ". ���� �޴���.." << endl;

			cout << "�޴��� �����ϼ��� >> ";
			int cmd;
			cin >> cmd;
			//---------------------------

			if ( cmd == sz + 1 )  
				break; 

			if ( cmd < 1 || cmd > sz + 1 )
				continue;

			v[cmd-1]->command(); 
		}
	}
};
*/

#include "Helper.h"

void foo()      { cout << "foo" << endl; getch();}
void goo(int a) { cout << "goo " << a << endl; getch();}

int main()
{
	PopupMenu* menubar = new PopupMenu("�޴���");
	PopupMenu* p1 = new PopupMenu("ȭ�� ����");

	MenuItem* m1 = new MenuItem("�ػ� ����", 11);
	MenuItem* m2 = new MenuItem("����  ����", 12);

	m1->addHandler( bind(&goo, 11)  );
	m2->addHandler( bind(&goo, 12) ); //?

	p1->addMenu( m1);
	p1->addMenu( m2);

	menubar->addMenu(p1);

	// ���� ���� �Ϸ���!!
	menubar->command();

	delete menubar;
}




