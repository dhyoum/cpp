// 4_Proxy
#include <iostream>
#include "ioacademy.h"
#include <conio.h>
using namespace std;
using namespace ioacademy;

int main()
{
	int handle = IoFindServer("CalcServer");
	cout << "���� ��ȣ : " << handle << endl;

	while( 1 )
	{
		getch(); 
		cout << IoSendServer( handle, 1, 1, 2) << endl;
		getch(); 
		cout << IoSendServer( handle, 2, 1, 2) << endl;
	}
}



