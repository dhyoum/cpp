// 6_GUI
#include <iostream>
#include "ioacademy.h"
#include <conio.h>
using namespace std;
using namespace ioacademy;

int handler( int handle, int msg, int param1, int param2)
{
	switch( msg )
	{
	case WM_LBUTTONDOWN: cout << "LBUTTON" << endl; break;
	case WM_KEYDOWN:     cout << "KEYDOWN" << endl; break;
	}
	return 0;
}
int main()
{
	int h1 = IoMakeWindow(handler);
	int h2 = IoMakeWindow(handler);
	
	// �ڽ�������� ���̱�
	IoAddChild( h1, h2); // �θ��ڵ�, �ڽ��ڵ�
	IoProcessMessage();
}

