// 6_GUI
#include <iostream>
#include "ioacademy.h"
#include <conio.h>
using namespace std;
using namespace ioacademy;
#include <map>

class Window;

map<int, Window*> this_map;

class Window
{
	int handle;
public:
	void Create() 
	{
		handle = IoMakeWindow( handler); 
		this_map[handle] = this;
	}
	static int handler( int h, int msg, int param1, int param2)
	{
		Window* pThis = this_map[h];

		switch( msg )
		{
		case WM_LBUTTONDOWN: pThis->OnLButtonDown(); break;
		case WM_KEYDOWN:     pThis->OnKeyDown();     break;
		}
		return 0;
	}
	virtual void OnLButtonDown() {}
	virtual void OnKeyDown() {}
};
// ��������� ���̺귯�� �����Դϴ�.
//-----------------------------------
// ���̺귯�� ����ڴ� Window�� �Ļ�Ŭ������ ����� �˴ϴ�.
class MyWindow : public Window
{
public:
	virtual void OnLButtonDown()
	{
		cout << "MyWindow LBUTTONDOWN" << endl;
	}
};

int main()
{
	MyWindow w;
	w.Create();

	IoProcessMessage();
}

