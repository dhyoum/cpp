// 6_GUI
#include <iostream>
#include "ioacademy.h"
#include <conio.h>
using namespace std;
using namespace ioacademy;
#include <map>
#include <vector>

class Window;

map<int, Window*> this_map;

class Window
{
	int handle;

	//-----------------
	Window* parent;

	vector<Window*> v;
public:
	Window() : parent(0) {}

	void addChild( Window* p)
	{
		p->parent = this;
		v.push_back(p);

		// C �Լ��� ����ؼ� �ڽ������츦 ���δ�.
		IoAddChild( this->handle, p->handle);
	}
	//----------------------------------------



	void Create() 
	{
		handle = IoMakeWindow( handler); 
		this_map[handle] = this;
	}
	static int handler( int h, int msg, int param1, int param2)
	{
		Window* pThis = this_map[h];

		switch( msg )
		{
		case WM_LBUTTONDOWN: pThis->OnLButtonDown(); break;
		case WM_KEYDOWN:     pThis->OnKeyDown();     break;
		}
		return 0;
	}
	virtual void OnLButtonDown() {}
	virtual void OnKeyDown() {}
};

class MyWindow : public Window
{
public:
	virtual void OnLButtonDown()
	{
		cout << "MyWindow LBUTTONDOWN" << endl;
	}
};

int main()
{
	MyWindow w;
	w.Create();

	MyWindow w2;
	w2.Create();

	// w2�� w�� �ڽ����� �ٿ� ������
	w.addChild(&w2);

	IoProcessMessage();
}



