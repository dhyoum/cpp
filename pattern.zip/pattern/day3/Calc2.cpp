#include <iostream>
#include "ioacademy.h"
#include "ICalc.h"   // �� ��� ���弼��..
using namespace std;
using namespace ioacademy;

// cl calc2.cpp /LD /link user32.lib gdi32.lib kernel32.lib
// "calc2.dll"
class RefBase :  virtual public IUnknown2
{
	int mCount;
public:
	RefBase() : mCount(0) {}
	virtual ~RefBase() {  }

	virtual void AddRef() { ++mCount; }
	virtual void Release(){ if ( --mCount == 0 ) delete this; }
};

class Calc : public ICalc, public RefBase
{
	int handle;
public:
	Calc() { handle = IoFindServer("CalcServer");}
	~Calc() { cout << "Calc �ı�" << endl; }

	int Add(int a, int b){ return IoSendServer(handle,1,a,b);}
	int Sub(int a, int b){ return IoSendServer(handle,2,a,b);}
};

extern "C" __declspec(dllexport)
ICalc* CreateCalc() { return new Calc;}

/*
// .dll ���� new�� �Ѱ�� .dll���� delete�� å�����°��� ����.
extern "C" __declspec(dllexport)
void DeleteCalc( ICalc* p) { delete p;}
*/





