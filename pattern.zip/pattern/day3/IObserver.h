// IObserver.h

struct IObserver
{
	virtual void OnUpdate( void* data ) = 0;
	virtual ~IObserver() {}
};
